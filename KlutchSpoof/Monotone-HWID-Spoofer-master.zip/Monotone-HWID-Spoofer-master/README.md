# Monotone-HWID-Spoofer
Custom Created Hardware ID Spoofer to Bypass Hardware or IP Bans
<br>
## How To Use
* `git clone https://github.com/sr2echa/Monotone-HWID-Spoofer.git`
* cd `Monotone-HWID-Spoofer`
* open monotone.exe
* give admin privilages
* click 'Unban'
* Enjoy

## Disclaimer
Works for Games like Rust, Fortnite, Apex Legends, etc. that dont use Kernal Based Anti-Cheat [eg. Valorant - Riot Vanguard]

